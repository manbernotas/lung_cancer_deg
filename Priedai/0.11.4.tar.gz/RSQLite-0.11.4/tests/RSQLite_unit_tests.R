library("RSQLite")
RSQLite:::.test()

